SigmaGraph v2.6.10
Copyright(C) 1997-2018  Sidi OULD SAAD HAMADY
All rights reserved.
http://www.hamady.org
sidi@hamady.org

See Copyright Notice in license.txt

Documentation in help\sigmagraph.pdf

SigmaGraph is a data plotting and analysis software designed to be lightweight, reliable and easy to use.
SigmaGraph runs on Windows XP, Vista and Windows 7/8/10.

Install:
unzip the portable version (sigmagraph_portable.zip) in any location (USB key for example) and run SigmaGraph.exe located in the bin directory.

The SigmaGraph package contains two executables (in the bin directory):
�	SigmaGraph.exe : main SigmaGraph component.
�	SigmaConsole.exe : mathematical console.
